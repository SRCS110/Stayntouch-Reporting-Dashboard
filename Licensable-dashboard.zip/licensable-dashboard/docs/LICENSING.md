# Licensing Model

## Tiers

| Tier  | Duration | Properties | PMS Pipeline | Price (suggested) |
|-------|----------|------------|--------------|-------------------|
| TRIAL | 30 days  | 1          | No           | Free              |
| PRO   | 1 year   | 1          | SFTP + API   | TBD               |
| MULTI | 1 year   | Unlimited  | SFTP + API   | TBD               |

## How It Works

1. Customer signs up → account is created in the database
2. A license key is generated: `node scripts/generate-license.js <propertyId> PRO`
3. Key is emailed to the customer and stored in their user record
4. Every API request passes through `middleware/license.js` which validates the key
5. Expired or invalid keys return HTTP 403 with an upgrade URL

## Key Format

```
HD-{TIER}-{PROP_HASH}-{EXPIRY}-{CHECKSUM}
Example: HD-PRO-A3F9-20261231-7C2B
```

Keys are HMAC-signed with `LICENSE_SECRET` from `.env`. Changing this secret invalidates all existing keys.

## Phase 1 (Current)

No licensing enforced. The password gate (`GATE_HASH` in `client/index.html`) provides basic access control. This is suitable for testing and single-operator use.

## Phase 4 (Planned)

- Self-serve signup with Stripe payment integration
- License keys emailed automatically on payment
- Admin panel to view active licenses, usage, and renewals
- White-label: customers can use their own branding (MULTI tier)
