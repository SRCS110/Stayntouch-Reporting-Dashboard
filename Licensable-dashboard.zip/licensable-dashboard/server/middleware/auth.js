/**
 * JWT authentication middleware.
 * Attach to any route that requires a logged-in user.
 *
 * Usage:
 *   const auth = require('../middleware/auth');
 *   router.get('/entries', auth, entriesController.list);
 */
const jwt = require('jsonwebtoken');

module.exports = function auth(req, res, next) {
  const header = req.headers['authorization'];
  if (!header || !header.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'No token provided.' });
  }

  const token = header.slice(7);
  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    req.user = decoded; // { userId, propertyId, email, licenseKey }
    next();
  } catch (err) {
    return res.status(401).json({ error: 'Invalid or expired token.' });
  }
};
